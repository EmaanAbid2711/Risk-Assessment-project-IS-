const express = require('express');
const router = express.Router();
const path = require('path');
const User = require(path.join(__dirname, '../models/User'));
const Assessment = require(path.join(__dirname, '../models/Assessment'));
const bcrypt = require('bcryptjs');
// User registration
router.post('/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;
        await User.createUser(username, email, password);
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// User login
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findByUsername(username);
        
        if (!user || !(await bcrypt.compare(password, user.password_hash))) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        req.session.userId = user.id;
        res.json({ message: 'Logged in successfully' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Submit assessment
router.post('/assessments', async (req, res) => {
    if (!req.session.userId) return res.status(401).json({ error: 'Unauthorized' });
    
    try {
        const result = await Assessment.saveAssessment(req.session.userId, req.body);
        res.json({ score: result.score, assessmentId: result.id });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Get assessment history
router.get('/assessments', async (req, res) => {
    if (!req.session.userId) return res.status(401).json({ error: 'Unauthorized' });
    
    try {
        const assessments = await Assessment.getAssessments(req.session.userId);
        res.json(assessments);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

module.exports = router;
