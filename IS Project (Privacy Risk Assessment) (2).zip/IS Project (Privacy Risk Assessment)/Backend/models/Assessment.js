const db = require('../config/db');
const { encrypt, decrypt } = require('../utils/encryption');

module.exports = {
    saveAssessment: async (userId, data) => {
        const score = calculatePrivacyScore(data);
        const encrypted = encrypt(data);

        const [result] = await db.execute(
            'INSERT INTO assessments (user_id, encrypted_data, iv, privacy_score) VALUES (?, ?, ?, ?)',
            [userId, encrypted.content, encrypted.iv, score]
        );

        return { id: result.insertId, score };
    },

    getAssessments: async (userId) => {
        const [rows] = await db.execute(
            'SELECT id, encrypted_data, iv, privacy_score, created_at FROM assessments WHERE user_id = ? ORDER BY created_at DESC',
            [userId]
        );

        return rows.map(row => ({
            id: row.id,
            data: decrypt({ content: row.encrypted_data, iv: row.iv }),
            score: row.privacy_score,
            createdAt: row.created_at
        }));
    }
};

function calculatePrivacyScore(data) {
    let score = 0;
    if (data.sharesLocation === 'always') score += 20;
    if (data.sharesLocation === 'sometimes') score += 10;
    if (data.usesSocialMedia === 'yes') score += 15;
    if (data.numberOfAccounts > 5) score += 5 * (data.numberOfAccounts - 5);
    if (data.usesPublicWifi === 'yes') score += 10;
    if (data.passwordHabits === 'reuse') score += 15;
    if (data.twoFactorEnabled === 'no') score += 10;
    return Math.min(score, 100); // Cap at 100
}
