const db = require('../config/db');
const bcrypt = require('bcryptjs');

module.exports = {
  // Create new user
  createUser: async (username, email, password) => {
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const [result] = await db.execute(
        'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
        [username, email, hashedPassword]
      );
      return result.insertId;
    } catch (error) {
      if (error.code === 'ER_DUP_ENTRY') {
        throw new Error('Username or email already exists');
      }
      throw error;
    }
  },

  // Find user by username
  findByUsername: async (username) => {
    const [rows] = await db.execute(
      'SELECT * FROM users WHERE username = ? LIMIT 1',
      [username]
    );
    return rows[0];
  },

  // Find user by email
  findByEmail: async (email) => {
    const [rows] = await db.execute(
      'SELECT * FROM users WHERE email = ? LIMIT 1',
      [email]
    );
    return rows[0];
  },

  // Verify user credentials
  verifyCredentials: async (username, password) => {
    const user = await this.findByUsername(username);
    if (!user) {
      return null;
    }
    
    const isValid = await bcrypt.compare(password, user.password_hash);
    return isValid ? user : null;
  },

  // Update user password
  updatePassword: async (userId, newPassword) => {
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await db.execute(
      'UPDATE users SET password_hash = ? WHERE id = ?',
      [hashedPassword, userId]
    );
  },

  // Delete user account
  deleteUser: async (userId) => {
    await db.execute(
      'DELETE FROM users WHERE id = ?',
      [userId]
    );
  },

  // Get user by ID
  getUserById: async (userId) => {
    const [rows] = await db.execute(
      'SELECT id, username, email, created_at FROM users WHERE id = ? LIMIT 1',
      [userId]
    );
    return rows[0];
  }
};